
#ifndef __PACKET_H__
#define __PACKET_H__

typedef struct payload_t
{
  double valeur;
  int id_capteur;
} payload_t;

#endif

